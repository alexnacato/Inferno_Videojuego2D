# Plan de pruebas en Godot 4 — Proyecto unificado

**Prioridad 1: importación y compilación.** Importa `project.godot` en Godot 4.3+, deja terminar la importación, abre la pestaña **Errores** y comprueba que no aparezcan errores de parser GDScript ni dependencias faltantes. Si aparece alguno, registra el **archivo y número de línea**: no hay que ocultarlo ni ignorarlo.

**Prioridad 2: Limbo.** Inicia partida nueva; mueve a Dante con WASD y flechas; verifica escala de sprite, esquiva, colisiones de estanques/estatuas, interacción con Virgilio, lectura de la inscripción, orden de tres santuarios, decisiones de Elio y Livia, cuadros de pergamino, retratos, minimapa, pausa y guardado. Prueba Espacio junto a ambas orillas de los lagos: debe saltar y aterrizar en el camino opuesto; al caminar o esquivar, el agua debe bloquear el paso. Antes del desbloqueo, la puerta debe permanecer cerrada.

**Prioridad 3: transición.** Tras tres santuarios y dos decisiones, habla con la puerta del norte. Debe aparecer **Del silencio al vendaval**, mostrando Redención y Rigor. Pulsa **Continuar a Lujuria**; debe iniciar el círculo II sin cerrar la aplicación. Regresa al menú con Escape y usa **Continuar**: se debe restaurar el capítulo II, no el I.

**Prioridad 4: Dante y HUD.** Comprueba lado a lado que su tamaño en ambos capítulos sea equivalente; el dibujo de Dante se obtiene del mismo spritesheet y a la misma escala. Revisa que en Lujuria cambien título, minimapa y objetivos, pero no el marco ni retratos de la interfaz del Limbo. Prueba especialmente diálogos con Paolo y Francesca, dos botones y selección con teclado.

**Prioridad 5: Lujuria.** Prueba viento sobre Dante y enemigos, esquiva, ataque J, proyectil K, colisión del abismo, oleadas de diablillo, carcelero, espectro y furia, daño y regreso al checkpoint, tres sellos en orden, dos almas y la invocación de Minos. Recorre ambas plazas laterales y verifica que se pueda caminar por su suelo pero no por los huecos bajo los balcones. Comprueba las esculturas y retratos de Virgilio, Paolo y Francesca; el personaje no debe atravesarlas. Dante no debe desplazarse solo por el viento ni quedar atrapado contra un enemigo. Valida que los enemigos rodeen la estatua sin atravesarla, no se superpongan y no golpeen a través de ella. Comprueba las dos fases de Minos, que su barra compacta permanezca arriba sin tapar el combate y que el título «II · LUJURIA» no invada el minimapa. La puerta debe estar bloqueada hasta vencerlo.

**Prioridad 6: persistencia moral.** Anota Redención y Rigor al terminar el Limbo. Haz una elección compasiva y otra rigurosa en Lujuria y comprueba que se sumen al total previo. Cierra y reabre Godot; **Continuar** debe recuperar sellos, almas, derrotas y checkpoint sin duplicar puntos ni regenerar enemigos derrotados.

**Prioridad 7: transición a Gula.** Al derrotar Minos, interactúa con la puerta norte. Debe verse **Lujuria completada** con los valores acumulados. Pulsa **Continuar a Gula** y comprueba que abre el círculo III sin cerrar el juego.

**Prioridad 8: Gula.** Recorre la entrada sur, ambos patios laterales y la arena superior. Verifica que Dante no camina por el estanque central ni el abismo; los charcos deben ralentizar movimiento y esquiva. Interactúa con ambas ofrendas y confirma que se hunden. Habla con Daria y Olmo, toma decisiones y comprueba que Redención o Rigor se acumulan. Cerbero debe aparecer tras los cuatro objetivos, mostrar su barra de salud y atacar con mordida, aullido y zarpazo. Derrotarlo debe liberar la puerta norte y abrir **Gula completada**. Vuelve al menú y elige **Continuar** para comprobar que no reaparece el jefe ni se pierden las decisiones.

### Verificación automatizada

`godot --headless --path . --script res://tests/navigation_smoke.gd`

`godot --headless --path . --script res://tests/gula_smoke.gd`

La primera prueba revisa Limbo y Lujuria; la segunda verifica rutas, lodo, objetivos, decisiones, Cerbero, guardado y pantallas de Gula. Deben terminar con `Navegación: todas las comprobaciones pasaron` y `Gula: todas las comprobaciones pasaron`, respectivamente. La revisión visual, de audio y del flujo completo sigue requiriendo una partida manual.
