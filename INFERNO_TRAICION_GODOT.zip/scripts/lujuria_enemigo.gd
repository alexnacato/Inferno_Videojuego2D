extends CharacterBody2D
const WALK_SOLVER = preload("res://scripts/walk_solver.gd")
## Reusable combat controller: 5 enemy archetypes, telegraphed attacks and boss phases.
signal died(spawn_id: String, archetype: String)
signal hp_changed(current: int, maximum: int)

const STATS := {
	"diablillo": {"hp": 5, "speed": 116.0, "range": 63.0, "cooldown": 1.65, "damage": 1, "radius": 16.0, "name": "Diablillo del Vendaval"},
	"carcelero": {"hp": 10, "speed": 74.0, "range": 85.0, "cooldown": 2.25, "damage": 2, "radius": 23.0, "name": "Carcelero de las Cadenas"},
	"espectro": {"hp": 6, "speed": 103.0, "range": 230.0, "cooldown": 2.1, "damage": 1, "radius": 17.0, "name": "Espectro del Remolino"},
	"furia": {"hp": 13, "speed": 107.0, "range": 77.0, "cooldown": 1.85, "damage": 2, "radius": 22.0, "name": "Furia del Anhelo"},
	"minos": {"hp": 38, "speed": 55.0, "range": 250.0, "cooldown": 2.9, "damage": 2, "radius": 35.0, "name": "Minos, juez de los deseos"},
}
const VISUAL_SCALE := {"diablillo": 0.60, "carcelero": 0.82, "espectro": 0.72, "furia": 0.78, "minos": 0.93}
@export_enum("diablillo", "carcelero", "espectro", "furia", "minos") var archetype := "diablillo"
@export var spawn_id := "foe_0"
var world
var hero
var anchor := Vector2.ZERO
var hp := 1
var max_hp := 1
var active := false
var dead := false
var move_dir := Vector2.DOWN
var attack_cooldown := 1.1
var windup := 0.0
var recovery := 0.0
var stagger := 0.0
var fade_time := 0.0
var attack_target := Vector2.DOWN
var phase := 1
var knockback := Vector2.ZERO
var ai_time := 0.0
var roaming_offset := Vector2.ZERO
var body_radius := 17.0
var route: PackedVector2Array = PackedVector2Array()
var route_time := 0.0
@onready var art: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
	if not STATS.has(archetype):
		archetype = "diablillo"
	max_hp = int(STATS[archetype]["hp"])
	hp = max_hp
	anchor = global_position
	var shape := CircleShape2D.new()
	body_radius = float(STATS[archetype]["radius"])
	shape.radius = body_radius
	$CollisionShape2D.shape = shape
	var scale_factor: float = float(VISUAL_SCALE[archetype])
	art.scale = Vector2.ONE * scale_factor
	art.position.y = -(88.0 if archetype == "minos" else 72.0) * scale_factor
	art.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	_setup_animations()
	art.play("idle")
	queue_redraw()

func _physics_process(delta: float) -> void:
	if dead:
		fade_time += delta
		if fade_time > 0.68:
			queue_free()
		return
	if not active or not is_instance_valid(hero) or not is_instance_valid(world) or not world.game_active:
		return
	attack_cooldown = maxf(attack_cooldown - delta, 0.0)
	recovery = maxf(recovery - delta, 0.0)
	stagger = maxf(stagger - delta, 0.0)
	knockback = knockback.move_toward(Vector2.ZERO, 410.0 * delta)
	ai_time += delta
	route_time = maxf(0.0, route_time - delta)
	var delta_to_hero: Vector2 = hero.global_position - global_position
	var dist: float = delta_to_hero.length()
	var stats: Dictionary = STATS[archetype]
	var motion := Vector2.ZERO
	var guarding: bool = archetype == "minos" and anchor.distance_to(hero.global_position) > 370.0
	if (dist < 505.0 or guarding) and stagger <= 0.0 and recovery <= 0.0:
		if windup > 0.0:
			windup -= delta
			if windup <= 0.0:
				_release_attack()
		elif not guarding and attack_cooldown <= 0.0 and dist <= float(stats["range"]) and world.has_clear_path(global_position, hero.global_position):
			windup = 0.58 if archetype == "minos" else 0.37
			attack_target = delta_to_hero.normalized()
			if attack_target.length_squared() < 0.001:
				attack_target = Vector2.DOWN
		elif guarding and global_position.distance_to(anchor) > 24.0 or not guarding and (dist > float(stats["range"]) * (0.77 if archetype == "espectro" else 0.72) or not world.has_clear_path(global_position, hero.global_position)):
			if route_time <= 0.0:
				var chase_point: Vector2 = anchor if guarding else hero.global_position
				if archetype == "diablillo" and not guarding and dist > 105.0 and dist < 320.0:
					var side: float = -1.0 if spawn_id.hash() % 2 == 0 else 1.0
					var flank: Vector2 = chase_point + delta_to_hero.normalized().orthogonal() * side * 52.0
					if world.can_walk(flank, body_radius):
						chase_point = flank
				route = world.route_to(global_position, chase_point, body_radius)
				route_time = 0.42
			while route.size() > 0 and global_position.distance_to(route[0]) < 18.0:
				route.remove_at(0)
			var destination: Vector2 = route[0] if route.size() > 0 else anchor if guarding else hero.global_position
			motion = global_position.direction_to(destination) * float(stats["speed"])
		elif archetype == "espectro" and dist < 115.0:
			motion = -delta_to_hero.normalized() * 57.0
	var wind: Vector2 = world.wind_at(global_position) * (0.27 if archetype == "minos" else 0.50)
	velocity = motion + wind + knockback
	var displacement: Vector2 = velocity * delta
	var steps: int = maxi(1, ceili(displacement.length() / 7.0))
	var step: Vector2 = displacement / float(steps)
	var can_enter: Callable = Callable(world, "can_occupy_enemy").bind(self, body_radius)
	for i in range(steps):
		global_position = WALK_SOLVER.step(global_position, step, can_enter)
	if route.size() > 0 and global_position.distance_to(route[0]) < 18.0:
		route.remove_at(0)
	if motion.length_squared() > 1.0:
		move_dir = motion.normalized()
	if stagger > 0.0:
		_play("hurt")
	elif windup > 0.0 or recovery > 0.0:
		_play("attack")
	elif motion.length_squared() > 10.0:
		_play("walk")
	else:
		_play("idle")
	if archetype == "minos" and phase == 1 and hp <= max_hp / 2:
		phase = 2
		world.notify("¡Minos ha desatado la segunda tempestad!")
	queue_redraw()

func _release_attack() -> void:
	if dead or not is_instance_valid(world):
		return
	var stats: Dictionary = STATS[archetype]
	var cooldown_scale := 0.72 if archetype == "minos" and phase == 2 else 1.0
	attack_cooldown = float(stats["cooldown"]) * cooldown_scale
	recovery = 0.34
	var toward: Vector2 = attack_target.normalized()
	if archetype == "espectro":
		world.spawn_projectile(global_position + toward * 28.0, toward, true, 1)
	elif archetype == "minos":
		var count := 7 if phase == 2 else 5
		for i in range(count):
			var arc: float = lerpf(-0.69, 0.69, float(i) / float(count - 1))
			world.spawn_projectile(global_position + toward * 34.0, toward.rotated(arc), true, int(stats["damage"]))
		if phase == 2:
			world.pulse_wind(global_position, 290.0)
	elif archetype == "carcelero":
		if is_instance_valid(hero) and global_position.distance_to(hero.global_position) < 105.0 and world.has_clear_path(global_position, hero.global_position) and attack_target.dot(global_position.direction_to(hero.global_position)) > 0.2:
			hero.take_damage(int(stats["damage"]))
			world.notify("Las cadenas de un carcelero alcanzan a Dante")
	else:
		if is_instance_valid(hero) and global_position.distance_to(hero.global_position) < float(stats["range"]) + 14.0 and world.has_clear_path(global_position, hero.global_position) and attack_target.dot(global_position.direction_to(hero.global_position)) > 0.4:
			hero.take_damage(int(stats["damage"]))
		if archetype == "furia":
			world.pulse_wind(global_position, 120.0)

func take_damage(amount: int, from_direction: Vector2 = Vector2.DOWN) -> void:
	if dead or not active:
		return
	hp = maxi(0, hp - maxi(0, amount))
	stagger = 0.19
	knockback = from_direction.normalized() * (90.0 if archetype == "minos" else 175.0)
	hp_changed.emit(hp, max_hp)
	if hp <= 0:
		dead = true
		collision_layer = 0
		collision_mask = 0
		_play("death")
		died.emit(spawn_id, archetype)
	else:
		_play("hurt")

func _play(name: String) -> void:
	if art.sprite_frames != null and art.sprite_frames.has_animation(name):
		if art.animation != name or not art.is_playing():
			art.play(name)

func _setup_animations() -> void:
	var lib := SpriteFrames.new()
	var size := Vector2(176.0, 176.0) if archetype == "minos" else Vector2(128.0, 144.0)
	for action in ["idle", "walk", "attack", "hurt", "death"]:
		var path: String = "res://assets/lujuria/enemies/%s/%s.png" % [archetype, action]
		var texture: Texture2D = load(path)
		if texture == null:
			continue
		lib.add_animation(action)
		lib.set_animation_speed(action, 7.0 if action != "walk" else 9.0)
		lib.set_animation_loop(action, action == "idle" or action == "walk")
		var count: int = maxi(1, int(texture.get_width() / size.x))
		for i in range(count):
			var frame := AtlasTexture.new()
			frame.atlas = texture
			frame.region = Rect2(i * size.x, 0.0, size.x, size.y)
			lib.add_frame(action, frame)
	art.sprite_frames = lib

func _draw() -> void:
	var radius: float = float(STATS[archetype]["radius"])
	draw_ellipse_shadow(maxf(radius + 5.0, (176.0 if archetype == "minos" else 128.0) * art.scale.x * 0.35))
	if dead:
		return
	if windup > 0.0:
		draw_arc(Vector2.ZERO, float(STATS[archetype]["range"]) * (0.8 if archetype == "minos" else 0.55), 0, TAU, 42, Color(0.82, 0.42, 0.94, 0.45), 2.4)
		draw_line(Vector2.ZERO, attack_target * 65.0, Color(0.85, 0.47, 0.94, 0.75), 3.0)
	if archetype != "minos" and (hp < max_hp or is_instance_valid(hero) and global_position.distance_to(hero.global_position) < 310.0):
		var width: float = 96.0 if archetype == "minos" else clampf(80.0 * art.scale.x, 48.0, 68.0)
		var top: float = art.position.y - (88.0 if archetype == "minos" else 72.0) * art.scale.y - 12.0
		draw_rect(Rect2(-width / 2.0 - 2.0, top - 2.0, width + 4.0, 11.0), Color(0.06, 0.04, 0.09, 0.92))
		draw_rect(Rect2(-width / 2.0, top, width, 7.0), Color(0.30, 0.20, 0.33, 0.95))
		draw_rect(Rect2(-width / 2.0, top, width * float(hp) / float(max_hp), 7.0), Color("c88bdc") if archetype == "minos" else Color("d9858c"))
		draw_line(Vector2(-width / 2.0, top + 1.0), Vector2(-width / 2.0 + width * float(hp) / float(max_hp), top + 1.0), Color(1.0, 0.9, 1.0, 0.55), 1.0)

func draw_ellipse_shadow(radius: float) -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.34))
	draw_circle(Vector2.ZERO, radius + 8.0, Color(0.05, 0.01, 0.08, 0.45))
	draw_set_transform(Vector2.ZERO)
