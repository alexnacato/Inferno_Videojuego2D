# INFERNO: EL DESCENSO — Limbo + Lujuria + Gula + Traición (Godot 4)

## Nuevo escenario final: Traición

El círculo IX, **Cocito**, está disponible desde **Jugar Traición · Círculo IX** en el menú y desde la pantalla final de Gula. Incluye un mapa cenital de hielo y ruinas, dos juramentos que romper, las almas de Ugolino y Bocca con decisiones de Redención o Rigor, hielo fino peligroso, combate contra Lucifer, guardado y una pantalla de cierre. Los círculos IV–VIII no están implementados, por lo que el acceso desde Gula es un salto directo al escenario final.

Para importarlo, descomprime `INFERNO_TRAICION_GODOT.zip`, abre Godot 4 y elige el archivo `project.godot` de la carpeta descomprimida. También puedes abrir este proyecto sin usar el ZIP. Pulsa F5 y elige **Jugar Traición · Círculo IX**. La escena independiente está en `scenes/Traicion.tscn`.

La geometría del mapa se puede revisar con `node tests/traicion_geometry.cjs`. En una instalación de Godot, la prueba jugable se ejecuta con `godot --headless --path . --script res://tests/traicion_smoke.gd`.

Este proyecto reúne los escenarios de Limbo, Lujuria, Gula y Traición en un solo `project.godot`. Conserva la interfaz, los diálogos con decisiones y la persistencia entre escenarios. Limbo, Lujuria y Gula aparecen uno tras otro; desde Gula se puede saltar al círculo final.

## Abrir y jugar

1. Descomprime `INFERNO_TRAICION_GODOT.zip` en una carpeta nueva.
2. En **Godot 4**, selecciona **Importar**, elige el `project.godot` de esta carpeta y espera la importación de imágenes/audio.
3. Pulsa **F5**. El menú principal permite comenzar, continuar o jugar directamente Traición.
4. En el **Limbo**, resuelve Memoria → Saber → Compasión, escucha a Elio y Livia, y abre la puerta norte.
5. Aparece una pantalla de transición. Pulsa **Continuar a Lujuria** y Dante llegará al segundo círculo.
6. En **Lujuria**, activa Memoria → Aliento → Juicio, escucha a Paolo y Francesca, derrota a los demonios y a Minos, y abre la puerta norte.
7. En **Lujuria completada**, pulsa **Continuar a Gula**.
8. En **Gula**, atraviesa el lodo, hunde las dos ofrendas, escucha a Daria y Olmo, derrota a Cerbero y abre la puerta norte.
9. En **Gula completada**, puedes entrar directamente a **Traición**. Rompe los dos juramentos, escucha a Ugolino y Bocca, vence a Lucifer y cruza la salida. Los círculos IV–VIII aún no están creados.

### Controles

| Teclas | Acción | Limbo | Lujuria | Gula | Traición |
|---|---|---|---|---|---|
| WASD / flechas | Movimiento en ocho direcciones | Sí | Sí | Sí | Sí |
| ESPACIO | Esquiva; salto contextual entre orillas en Limbo | Sí | Sí | Sí | Sí |
| E | Interacción / hablar | Sí | Sí | Sí | Sí |
| Q | Pista de Virgilio | Sí | Sí | Sí | Sí |
| 1 / 2 o clic | Elegir diálogo | Sí | Sí | Sí | Sí |
| J | Ataque cercano | No | Sí | Sí | Sí |
| K | Verso de luz | No | Sí | Sí | Sí |
| ESC | Pausar / reanudar | Sí | Sí | Sí | Sí |

## Unificación realizada

- **Interfaz:** la escena `scenes/HUD.tscn` y el script `scripts/hud.gd` provienen de Limbo. El estilo pergamino se mantiene en ambos capítulos; Lujuria muestra los rostros de sus personajes en los diálogos. El HUD cambia de título, objetivos y minimapa automáticamente.
- **Dante:** Lujuria usa el mismo archivo de sprites de Limbo (`assets/dante/`), con **celdas 80×96**, la **misma escala 1.24**, desplazamiento visual `(0,-58)` y zoom de cámara **0.96**. Su script separado conserva las mecánicas de combate, viento y daño. Se mantienen dos scripts de controlador para no alterar el Limbo sin combate.
- **Progreso:** `scripts/game_state.gd` es un autoload llamado `Game`. Usa **un solo archivo** `user://inferno_save_v2.json`; Redención y Rigor se acumulan a través de los círculos. Los progresos de Limbo, Lujuria y Gula tienen claves separadas para evitar sobreescrituras.
- **Transición:** el final del Limbo lleva a `Transicion.tscn` y después a `Lujuria.tscn`. Volver al menú y elegir **Continuar** lleva al capítulo actual.
- **Lujuria:** se preservaron el mapa, el viento, los sellos, las almas, las oleadas enemigas, Minos y los proyectiles. Sus recursos están en `assets/lujuria/` y sus scripts empiezan con `lujuria_` para evitar conflictos.
- **Gula:** un mapa ilustrado nuevo se montó en Godot como `Sprite2D`; polígonos `Polygon2D` editables delimitan suelo y lodo. Incluye dos ofrendas que se hunden, dos decisiones morales y Cerbero con tres ataques. Consulta [GULA_ESCENARIO.md](GULA_ESCENARIO.md) para la explicación de diseño y la procedencia del arte.
- **Movimiento y colisiones:** Dante recorre el suelo visible con una zona de apoyo ajustada a sus pies. Al tocar un borde conserva el avance hasta él y se desliza por las curvas sin atravesarlas. En Limbo no puede caminar sobre los lagos; Espacio salta entre orillas cuando hay un aterrizaje seguro. En Lujuria se pueden recorrer las plazas laterales y se bloquean los huecos bajo sus balcones; el viento no arrastra a Dante en reposo y los enemigos no crean muros móviles.
- **Enemigos:** buscan rutas alrededor de la estatua, evitan superponerse con Dante y entre sí, y comprueban si hay línea despejada antes de atacar. Los diablillos intentan flanquear, los espectros conservan distancia y Minos protege su plataforma. Sus tamaños y sombras se ajustan por tipo; los enemigos se ordenan visualmente según su posición vertical.
- **Interfaz:** la barra de Minos ocupa una franja compacta arriba, junto al rótulo «II · LUJURIA». El centro de la pantalla queda libre durante el combate.
- **Personajes de Lujuria:** Virgilio, Paolo y Francesca son esculturas de piedra de cuerpo completo inspiradas directamente en el diseño del Limbo. Su tamaño es comparable al de las figuras del mapa, conservan la misma posición durante la interacción y sus rostros aparecen en los diálogos. Los recursos y sus instrucciones de generación están en `assets/lujuria/npcs/`.

## Archivos importantes

```text
project.godot
scenes/
  MenuPrincipal.tscn       # menú general
  Limbo.tscn               # capítulo I
  Transicion.tscn          # capítulo I → II
  Lujuria.tscn             # capítulo II
  FinLujuria.tscn          # transición II → III
  Gula.tscn                # capítulo III
  GulaCerbero.tscn         # guardián de Gula
  FinGula.tscn             # cierre del contenido actual
  Dante.tscn               # personaje del Limbo
  DanteLujuria.tscn        # mismo aspecto/escala, combate activo
  HUD.tscn                 # interfaz única reutilizada
  LujuriaEnemigo.tscn      # IA enemiga reutilizable
scripts/
  game_state.gd            # progreso moral de todo el viaje
  hud.gd                   # interfaz, retratos, dialogo de almas
  limbo.gd                 # lógica Limbo
  lujuria.gd               # lógica Lujuria y encuentros
  lujuria_enemigo.gd       # IA, Minos y efectos de viento
  lujuria_dante.gd         # movimiento/combate en Lujuria
  gula.gd                  # suelo, lodo, objetivos y progreso de Gula
  gula_cerbero.gd          # comportamiento de Cerbero
assets/
  dante/                  # arte idéntico para ambos círculos
  ui/                     # retratos y estilo de Limbo
  world/                  # mapa original del Limbo
  lujuria/                # arte, audio, NPC y enemigos del segundo círculo
  gula/                   # mapa, plano de rutas y Cerbero del tercer círculo
```

## Guardado y compatibilidad

El proyecto nuevo guarda el progreso en una carpeta de usuario correspondiente a su propio nombre. Los guardados de las **dos aplicaciones originales**, que tienen nombres de proyecto diferentes, **no se importan automáticamente**. Para comprobar la unión, inicia una **partida nueva** en este proyecto; no sobrescribe los ZIP originales.

Para probar un círculo directamente, abre `scenes/Lujuria.tscn` o `scenes/Gula.tscn` en el editor y ejecútalo con **F6**. Es un atajo de desarrollo que también actualiza el guardado; usa una partida de prueba si deseas conservar tu progreso.

## Comprobación

Se ejecutaron ambas escenas con **Godot 4.7.2** y una prueba automática de navegación. Esta verifica que los ocho puntos del Limbo y los siete de Lujuria sean alcanzables, que las esquivas no atraviesen lagos ni abismos, que el salto aterrice en el camino, que los enemigos aparezcan sobre suelo sin invadir a Dante, que uno de ellos rodee la estatua, que las plazas laterales sean transitables, que las figuras detalladas estén cargadas y que los paneles superiores no se superpongan.

Para repetir las pruebas desde la carpeta del proyecto: `godot --headless --path . --script res://tests/navigation_smoke.gd` y `godot --headless --path . --script res://tests/gula_smoke.gd`. Consulta `PRUEBAS.md` para la revisión visual y de audio dentro del editor.
