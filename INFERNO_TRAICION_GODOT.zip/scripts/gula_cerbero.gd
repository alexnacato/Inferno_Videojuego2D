extends Node2D

signal defeated
signal hp_changed(current: int, maximum: int)

const MAX_HP := 36
var max_hp := MAX_HP
var hp := MAX_HP
var active := true
var dead := false
var body_radius := 62.0
var world: Variant
var hero: Variant
var cooldown := 1.5
var windup := 0.0
var pattern := 0
var flash := 0.0

@onready var art: Sprite2D = $Sprite2D

func _ready() -> void:
    art.texture = load("res://assets/gula/enemies/cerbero.png")
    art.scale = Vector2.ONE * 0.19
    art.position = Vector2(0, -78)
    art.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    hp_changed.emit(hp, MAX_HP)

func _process(delta: float) -> void:
    if dead or not active or not is_instance_valid(world) or not world.game_active or not is_instance_valid(hero):
        return
    flash = maxf(0.0, flash - delta)
    art.modulate = Color(1.0, 0.65, 0.65) if flash > 0.0 else Color.WHITE
    var distance: float = global_position.distance_to(hero.global_position)
    if windup > 0.0:
        windup -= delta
        if windup <= 0.0:
            _release_attack()
            cooldown = 1.6 if hp > MAX_HP / 2 else 1.1
            pattern = (pattern + 1) % 3
    else:
        cooldown -= delta
        if cooldown <= 0.0 and distance < 420.0:
            windup = 0.78 if hp > MAX_HP / 2 else 0.58
    queue_redraw()

func _release_attack() -> void:
    var distance: float = global_position.distance_to(hero.global_position)
    match pattern:
        0: # Mordida frontal.
            if distance < 120.0:
                hero.take_damage(2)
        1: # Aullido: tres proyectiles visibles que se pueden esquivar.
            var direction := global_position.direction_to(hero.global_position)
            for angle in [-0.24, 0.0, 0.24]:
                world.spawn_projectile(global_position + direction * 55.0, direction.rotated(angle), true, 1)
        2: # Zarpazo circular, con aviso visual durante la preparación.
            if distance < 170.0:
                hero.take_damage(2)

func take_damage(amount: int, _direction: Vector2) -> void:
    if dead or not active or not is_instance_valid(world) or not world.game_active:
        return
    hp = maxi(0, hp - maxi(0, amount))
    flash = 0.16
    hp_changed.emit(hp, MAX_HP)
    if hp == 0:
        dead = true
        active = false
        visible = false
        defeated.emit()

func _draw() -> void:
    if dead:
        return
    draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.36))
    draw_circle(Vector2.ZERO, 64.0, Color(0, 0, 0, 0.4))
    draw_set_transform(Vector2.ZERO)
    if windup > 0.0:
        var reach := 120.0 if pattern == 0 else 220.0 if pattern == 1 else 170.0
        draw_arc(Vector2.ZERO, reach, 0.0, TAU, 64, Color(0.8, 1.0, 0.35, 0.65), 3.0)
