extends Node2D

## Círculo III: rutas de piedra, lodo que ralentiza y ofrendas que se hunden.
const BOSS_SCENE: PackedScene = preload("res://scenes/GulaCerbero.tscn")
const PROJECTILE_SCENE: PackedScene = preload("res://scenes/LujuriaProyectil.tscn")
const SPAWN := Vector2(724, 1015)
const SAMPLES := [Vector2.ZERO, Vector2.RIGHT, Vector2.LEFT, Vector2.UP, Vector2.DOWN,
    Vector2(0.7071, 0.7071), Vector2(-0.7071, 0.7071), Vector2(0.7071, -0.7071), Vector2(-0.7071, -0.7071)]

@onready var hero: Variant = $Dante
@onready var hud: Variant = $HUD
@onready var floors: Node2D = $Suelo
@onready var mud: Node2D = $Lodo
@onready var markers: Node2D = $Marcadores
@onready var foes: Node2D = $Enemigos
@onready var bullets: Node2D = $Proyectiles

var game_active := false
var paused := false
var offerings: Array[String] = []
var decided: Dictionary = {}
var boss_spawned := false
var boss_defeated := false
var intro_seen := false
var checkpoint := SPAWN
var dialogue_context := ""
var boss: Variant

func _ready() -> void:
    Game.enter_gula()
    hero.world = self
    hero.health_changed.connect(_on_health_changed)
    hero.exhausted.connect(_on_exhausted)
    hud.configure_chapter("gula", hero)
    hud.option_selected.connect(_on_dialogue_selected)
    hud.pause_requested.connect(_toggle_pause)
    hud.exit_to_menu_requested.connect(_back_to_menu)
    _load_state()
    hero.restore(hero.max_health, checkpoint)
    hero.control_enabled = true
    if boss_spawned and not boss_defeated:
        _spawn_boss()
    _refresh_hud()
    game_active = true
    if not intro_seen:
        _dialogue("intro", "VIRGILIO · CÍRCULO DE LA GULA",
            "La lluvia pudre el banquete y el lodo roba fuerza a tus pasos. Las ofrendas de ambos patios deben hundirse antes de enfrentar a Cerbero. Escucha también las voces que quedaron aquí.",
            ["Entrar en la Gula"])

func _process(_delta: float) -> void:
    hud.set_dash_fraction(1.0 - clampf(hero.dash_recharge / 0.85, 0.0, 1.0))
    if not game_active or paused or hud.dialogue_open:
        hud.set_nearby("")
        return
    var nearby: Variant = _nearest_marker()
    for marker in markers.get_children():
        marker.set("near", marker == nearby)
    hud.set_nearby(str(nearby.caption) if nearby != null else "")
    if Input.is_action_just_pressed("interact") and nearby != null:
        _use_marker(nearby)
    if Input.is_action_just_pressed("hint"):
        _show_hint()

func _draw() -> void:
    for area in mud.get_children():
        var polygon: PackedVector2Array = area.get("polygon")
        draw_colored_polygon(polygon, Color(0.27, 0.35, 0.10, 0.20))

func can_walk(p: Vector2, radius: float = 10.0) -> bool:
    for offset in SAMPLES:
        var sample: Vector2 = p + offset * radius
        var found := false
        for area in floors.get_children():
            var polygon: PackedVector2Array = area.get("polygon")
            if Geometry2D.is_point_in_polygon(sample, polygon):
                found = true
                break
        if not found:
            return false
    return true

func movement_factor(p: Vector2) -> float:
    for area in mud.get_children():
        var polygon: PackedVector2Array = area.get("polygon")
        if Geometry2D.is_point_in_polygon(p, polygon):
            return 0.56
    return 1.0

func can_occupy_hero(p: Vector2, _dodging: bool = false) -> bool:
    if not can_walk(p, 10.0):
        return false
    if is_instance_valid(boss) and not boss.dead and p.distance_to(boss.global_position) < 70.0:
        return false
    return true

func wind_at(_p: Vector2) -> Vector2:
    return Vector2.ZERO

func melee_hit(origin: Vector2, facing: Vector2) -> void:
    if not is_instance_valid(boss) or boss.dead or not boss.active:
        return
    var toward: Vector2 = boss.global_position - origin
    if toward.length() < 126.0 and toward.normalized().dot(facing) > 0.15:
        boss.take_damage(2, facing)

func spawn_projectile(start: Vector2, direction: Vector2, hostile: bool, hit_damage: int) -> void:
    var shot: Variant = PROJECTILE_SCENE.instantiate()
    shot.position = start
    shot.direction = direction.normalized()
    shot.enemy_owned = hostile
    shot.damage = hit_damage
    shot.speed = 245.0 if hostile else 355.0
    shot.world = self
    bullets.add_child(shot)

func _nearest_marker() -> Variant:
    var best: Variant
    var best_distance := 96.0
    for marker in markers.get_children():
        var marker_node: Node2D = marker as Node2D
        var distance: float = hero.global_position.distance_to(marker_node.global_position)
        if distance < best_distance:
            best = marker
            best_distance = distance
    return best

func _use_marker(marker: Variant) -> void:
    match str(marker.uid):
        "virgilio":
            _show_hint()
        "ofrenda_oeste", "ofrenda_este":
            _sink_offering(marker)
        "alma_daria", "alma_olmo":
            _talk_soul(str(marker.uid))
        "puerta":
            if boss_defeated:
                _complete_level()
            else:
                _toast("Cerbero custodia el umbral. Hunda las ofrendas y escuche a las almas.")

func _sink_offering(marker: Variant) -> void:
    var uid: String = str(marker.uid)
    if uid in offerings:
        _toast("La ofrenda ya se hundió en el lodo.")
        return
    offerings.append(uid)
    marker.set_done(true)
    _save_state()
    _refresh_hud()
    _dialogue("ofrenda", "OFRENDA HUNDIDA",
        "La ofrenda se hunde lentamente y el lodo se traga sus restos. %d de 2 ofrendas han desaparecido." % offerings.size(),
        ["Continuar"])
    _check_boss_spawn()

func _talk_soul(uid: String) -> void:
    if decided.has(uid):
        _dialogue("short", uid.to_upper(), "Tu decisión permanece conmigo.", ["Continuar"])
    elif uid == "alma_daria":
        _dialogue(uid, "DARIA · ALMA DE LA GULA",
            "Acumulé comida mientras mis vecinos pasaban hambre. Ahora solo veo banquetes podridos. ¿Puedo compartir lo que me queda, aunque sea tarde?",
            ["Permitirle reparar su falta · Redención", "Recordarle el daño que causó · Rigor"])
    else:
        _dialogue(uid, "OLMO · ALMA DE LA GULA",
            "Fui cocinero y desperdicié cuanto otros necesitaban. Aquí la mesa se hunde conmigo. ¿Merece mi oficio una segunda oportunidad?",
            ["Animarlo a alimentar a otros · Redención", "Juzgar su derroche · Rigor"])

func _dialogue(context: String, title: String, message: String, options: Array) -> void:
    dialogue_context = context
    game_active = false
    hero.control_enabled = false
    hud.show_dialogue(title, message, options)

func _on_dialogue_selected(choice: int) -> void:
    if dialogue_context == "intro":
        intro_seen = true
    elif dialogue_context == "alma_daria" or dialogue_context == "alma_olmo":
        if not decided.has(dialogue_context):
            decided[dialogue_context] = choice
            Game.decide(dialogue_context, choice == 0)
            for marker in markers.get_children():
                if str(marker.get("uid")) == dialogue_context:
                    marker.call("set_done", true)
            _save_state()
            _refresh_hud()
            _dialogue("short", "ECO DE LA GULA",
                "Tu decisión se suma a tu camino de Redención o Rigor.", ["Continuar"])
            _check_boss_spawn()
            return
    dialogue_context = ""
    _save_state()
    _refresh_hud()
    game_active = true
    hero.control_enabled = true

func _show_hint() -> void:
    if offerings.size() < 2:
        _toast("VIRGILIO: Busca las dos ofrendas en los patios laterales.", 5.0)
    elif decided.size() < 2:
        _toast("VIRGILIO: Escucha a Daria y Olmo antes de subir.", 5.0)
    elif not boss_defeated:
        _toast("VIRGILIO: Cerbero espera en la arena superior. Esquiva su aullido.", 5.0)
    else:
        _toast("VIRGILIO: La puerta del norte está libre.", 5.0)

func _check_boss_spawn() -> void:
    if boss_spawned or boss_defeated or offerings.size() < 2 or decided.size() < 2:
        return
    boss_spawned = true
    _spawn_boss()
    _save_state()
    _toast("¡Cerbero ha despertado en la arena superior!", 5.0)

func _spawn_boss() -> void:
    boss = BOSS_SCENE.instantiate()
    boss.position = Vector2(724, 257)
    boss.world = self
    boss.hero = hero
    boss.hp_changed.connect(hud.set_boss_health)
    boss.defeated.connect(_on_boss_defeated)
    foes.add_child(boss)
    hud.boss_text.text = "CERBERO"
    hud.set_boss_health(boss.hp, boss.max_hp)

func _on_boss_defeated() -> void:
    boss_defeated = true
    hud.hide_boss()
    for marker in markers.get_children():
        if str(marker.get("uid")) == "puerta":
            marker.call("set_done", true)
    _save_state()
    _refresh_hud()
    _toast("Cerbero ha caído. El umbral del norte está abierto.", 5.0)

func _load_state() -> void:
    var data: Dictionary = Game.progress
    var saved_offerings: Variant = data.get("gula_offerings", [])
    offerings.clear()
    if saved_offerings is Array:
        for value in saved_offerings:
            var uid: String = str(value)
            if uid in ["ofrenda_oeste", "ofrenda_este"] and not uid in offerings:
                offerings.append(uid)
    var saved_decisions: Variant = data.get("gula_decisions", {})
    decided = saved_decisions.duplicate(true) if saved_decisions is Dictionary else {}
    intro_seen = bool(data.get("gula_intro_seen", false))
    boss_spawned = bool(data.get("gula_boss_spawned", false))
    boss_defeated = bool(data.get("gula_boss_defeated", false))
    checkpoint = Vector2(float(data.get("gula_checkpoint_x", SPAWN.x)), float(data.get("gula_checkpoint_y", SPAWN.y)))
    if not can_walk(checkpoint, 10.0):
        checkpoint = SPAWN
    for marker in markers.get_children():
        var marker_id: String = str(marker.get("uid"))
        marker.call("set_done", marker_id in offerings or marker_id in decided or marker_id == "puerta" and boss_defeated)

func _save_state() -> void:
    Game.progress["circle"] = "gula"
    Game.progress["gula_started"] = true
    Game.progress["gula_offerings"] = offerings.duplicate()
    Game.progress["gula_decisions"] = decided.duplicate(true)
    Game.progress["gula_intro_seen"] = intro_seen
    Game.progress["gula_boss_spawned"] = boss_spawned
    Game.progress["gula_boss_defeated"] = boss_defeated
    Game.progress["gula_checkpoint_x"] = checkpoint.x
    Game.progress["gula_checkpoint_y"] = checkpoint.y
    Game.save_progress()

func _refresh_hud() -> void:
    hud.set_gula_state(Game.progress, offerings.size(), decided.size(), boss_defeated)
    hud.set_health(hero.health, hero.max_health)

func _on_health_changed(current: int, maximum: int) -> void:
    hud.set_health(current, maximum)

func _on_exhausted() -> void:
    game_active = false
    _toast("Dante cae en el lodo y vuelve al acceso del círculo...")
    await get_tree().create_timer(1.1).timeout
    if not is_inside_tree():
        return
    hero.restore(hero.max_health, checkpoint)
    hero.control_enabled = true
    game_active = true

func _complete_level() -> void:
    game_active = false
    hero.control_enabled = false
    Game.progress["gula_completed"] = true
    _save_state()
    get_tree().change_scene_to_file("res://scenes/FinGula.tscn")

func _toggle_pause() -> void:
    if hud.dialogue_open:
        return
    paused = not paused
    game_active = not paused
    hero.control_enabled = not paused
    hud.set_pause(paused)

func _back_to_menu() -> void:
    _save_state()
    get_tree().change_scene_to_file("res://scenes/MenuPrincipal.tscn")

func _toast(message: String, duration: float = 3.5) -> void:
    hud.toast(message, duration)
