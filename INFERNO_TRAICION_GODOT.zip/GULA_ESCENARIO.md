# Escenario III: Gula

## Qué se construyó

El tercer círculo continúa después de la pantalla «Lujuria completada». Dante entra por el sur en un banquete arruinado bajo la lluvia. Dos rampas bordean un estanque de lodo y llevan a patios laterales; ambas se reúnen en la arena de Cerbero y la puerta del norte.

La regla propia de Gula es el **lodo**: al pisar los charcos marcados, Dante se mueve y esquiva más lentamente. En los patios hay dos ofrendas que se hunden al interactuar. Daria y Olmo plantean decisiones de Redención o Rigor. Tras hundir ambas ofrendas y decidir sobre las dos almas, aparece Cerbero. Vencerlo libera la puerta y abre la pantalla final del círculo.

## Cómo se construyó en Godot

La ilustración de fondo y el sprite de Cerbero se generaron con la herramienta de imágenes de OpenAI, usando el mapa de Lujuria como **referencia de estilo**. Esos PNG se importaron al proyecto. La imagen de fondo se muestra con un nodo **Sprite2D**.

La escena jugable se montó en **Godot 4.7.2**. Los nodos **Polygon2D** bajo `Suelo` y `Lodo` delimitan zonas transitables y zonas lentas. Sus vértices pueden ajustarse en la vista 2D del editor; un script los muestra con colores de guía en el editor y los oculta durante el juego. Los marcadores, el jugador, el jefe y la interfaz son nodos separados. Por tanto, es correcto decir que el nivel se **integró y delimitó con herramientas 2D de Godot**. La ilustración no se dibujó con TileMapLayer ni se produjo dentro de Godot.

Archivos principales:

| Archivo | Función |
| --- | --- |
| [gula_base.png](assets/gula/world/gula_base.png) | Mapa ilustrado que ve el jugador. |
| [gula_rutas.png](assets/gula/world/gula_rutas.png) | Vista de revisión: verde = suelo transitable; cuadrados claros = interacciones. |
| [Gula.tscn](scenes/Gula.tscn) | Escena 2D con mapa, polígonos, Dante, marcadores, enemigos e interfaz. |
| [gula.gd](scripts/gula.gd) | Rutas, lodo, objetivos, decisiones, guardado y salida. |
| [cerbero.png](assets/gula/enemies/cerbero.png) | Sprite con fondo transparente. |
| [gula_cerbero.gd](scripts/gula_cerbero.gd) | Combate de Cerbero: mordida, aullido y zarpazo. |

## Abrir y mostrar al docente

1. Importar `project.godot` en Godot 4.7.2 y esperar la importación de imágenes.
2. Abrir `scenes/Gula.tscn` en el editor 2D. Mostrar el nodo `MapaPintado` y los polígonos bajo `Suelo` y `Lodo`.
3. Abrir `assets/gula/world/gula_rutas.png` para explicar entrada, patios, lodo, arena y salida.
4. Para jugar de forma directa, seleccionar `Gula.tscn` y pulsar **F6**. Para probar el flujo completo, terminar Lujuria y pulsar **Continuar a Gula**. La ejecución directa con F6 también actualiza el guardado del proyecto; usar una partida de prueba si se quiere conservar el progreso anterior.
5. Mostrar un charco que ralentiza, una ofrenda que se hunde, una decisión de alma, la aparición de Cerbero y la puerta norte tras vencerlo.

## Relación con el documento de concepto y la rúbrica

- **Coherencia:** mantiene el género 2D cenital, la ruta de descenso, la guía de Virgilio, las decisiones morales y la regla especial del tercer círculo: lodo que ralentiza y objetos que se hunden.
- **Visual:** piedra gris y sombras profundas con verde enfermizo como acento; la entrada, los patios laterales y la arena tienen siluetas distintas para orientar al jugador.
- **Objetos:** banquete arruinado, estatuas, arcos, lodo, ofrendas, Daria, Olmo, Cerbero y puerta norte.
- **Interacción:** dos rutas alrededor del estanque, dos patios explorables, charcos lentos, dos ofrendas, dos diálogos con elección, combate y salida condicionada.
- **Presentación grupal:** asignar a Gabriel, Alexander y Leidy solo los aportes que realmente hicieron; cada uno debe explicar una decisión visual o jugable y mostrarla en el mapa.

## Verificación

Se ejecutó `tests/gula_smoke.gd` con Godot 4.7.2. Comprueba la entrada, las zonas bloqueadas, el efecto del lodo, la accesibilidad de los seis puntos interactivos, las dos ofrendas, las dos decisiones, la aparición y derrota de Cerbero, el guardado y las pantallas de transición. Terminó con «Gula: todas las comprobaciones pasaron». La prueba anterior de navegación de Limbo y Lujuria también pasó después de integrar Gula.

La revisión visual de rutas se generó con `tests/gula_visual_debug.gd`. Antes de exponer, conviene jugar una partida completa en la ventana de Godot para revisar a ojo la escala del jefe, legibilidad del HUD, sonido y dificultad del combate.

## Texto breve para la exposición

«Gula es el tercer círculo de *Inferno: El Descenso*. El mapa conserva el estilo arquitectónico de los niveles anteriores, pero usa gris y verde enfermizo para mostrar un banquete en descomposición. La entrada está al sur y la salida al norte. Dos rutas rodean un estanque de lodo y llevan a patios donde el jugador hunde ofrendas y escucha a dos almas. El lodo ralentiza a Dante. Al completar los objetivos, Cerbero aparece en la arena superior y bloquea el descenso. La ilustración se generó como arte 2D y el escenario jugable se montó en Godot con Sprite2D, Polygon2D, marcadores y scripts».
